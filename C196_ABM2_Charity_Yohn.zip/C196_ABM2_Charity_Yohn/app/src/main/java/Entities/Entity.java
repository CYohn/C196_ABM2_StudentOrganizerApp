package Entities;


@Entity
public class Entity {
}
